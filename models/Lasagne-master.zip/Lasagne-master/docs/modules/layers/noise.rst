Noise layers
------------

.. automodule:: lasagne.layers.noise

.. currentmodule:: lasagne.layers

.. autoclass:: DropoutLayer
    :members:

.. autoclass:: dropout

.. autoclass:: GaussianNoiseLayer
    :members:


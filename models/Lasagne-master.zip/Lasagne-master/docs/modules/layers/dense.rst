Dense layers
------------

.. automodule:: lasagne.layers.dense

.. currentmodule:: lasagne.layers

.. autoclass:: DenseLayer
   :members:

.. autoclass:: NINLayer
    :members:

